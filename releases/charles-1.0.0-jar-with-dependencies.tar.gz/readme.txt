This zip contains: 

charles-1.0.0-jar-with-dependencies.jar -> "fat" jar containing the dependencies. Simply add this to your project's buildpath
and you should be good to go.

charles-1.0.0-jar-with-dependencies.jar.asc -> for verifying the pgp signature.
Find the public key at http://pgp.mit.edu (search for string "mihai andronache". keyID: B89DA9DC)
